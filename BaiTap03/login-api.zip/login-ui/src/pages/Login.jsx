import { useState } from "react";

const [isLogin, setIsLogin] = useState(true);

const [loginEmail, setLoginEmail] = useState("");
const [loginPassword, setLoginPassword] = useState("");

const [registerEmail, setRegisterEmail] = useState("");
const [registerPassword, setRegisterPassword] = useState("");
const [registerName, setRegisterName] = useState("");
const [registerAvatar, setRegisterAvatar] = useState("");

<h2 className="p-3 text-3xl font-bold text-ping-400">App</h2>
<div className="inline-block border-[1px] justify-center w-20 border-blue-400 border-solid"></div>
